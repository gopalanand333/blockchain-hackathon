sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("landRecord.controller.View1", {
		onInit : function(){
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		},
		registrationPress : function(){
			this.oRouter.navTo("registrationPage");
		},
		rtcPress : function(oEvent){
			this.oRouter.navTo("rtc");
		},
		mutation : function(){
				this.oRouter.navTo("View4");
		}
	});
});