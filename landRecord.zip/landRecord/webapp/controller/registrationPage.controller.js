sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	'sap/ui/core/Fragment'
], function(Controller, MessageToast, Fragment) {
	"use strict";
var _timeout;
	return Controller.extend("landRecord.controller.registrationPage", {
		goHome: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");
		},
		sendOTP: function() {
			MessageToast.show("OTP SENT");
			this.byId("OTP").setEnabled(true);
		},
		checkOTP: function() {
			if (parseInt(this.byId("OTP").getValue(), 10) === 1234) {
				MessageToast.show("Success : You can Proceed Now");
				this.byId("validation").setVisible(false);
				this.byId("register").setVisible(true);
			}
		},
		registerToChain: function(oEvent) {
				this.byId("register").setVisible(false);
			this.byId("upload").setVisible(true);
				_timeout = jQuery.sap.delayedCall(5000, this, function () {
						MessageToast.show("Saved And Distributed");
			});
				_timeout = jQuery.sap.delayedCall(6000, this, function () {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");
			});
		
		}
		
	});
});