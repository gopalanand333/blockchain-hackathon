sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("landRecord.controller.View4", {
		goHome : function(oevent){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("registrationPage");
		},
		seeDetails : function(){
			this.byId("searchResults").setVisible(true);
		},
		onInit: function () {
			var aData = [
				{ product: "Sold By Mahesh", type: "LockedBy" , additionalInfo: " : SBI Bank"},
				{ product: "Sold By Ramesh", type: "LockedBy", additionalInfo: " : Gabbar" },
				{ product: "Bought By Suresh", type: "LockedBy" },
				{ product: "Bought By Government", type: "Unsaved" }
			];
			var oModel = new sap.ui.model.json.JSONModel({
				modelData: aData
			});
			this.getView().setModel(oModel);
		},
		onPress: function(oEvent) {
			sap.m.MessageToast.show(oEvent.getParameter("type") + " marker pressed!");
		}
	});
});